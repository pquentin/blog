long FAR PASCAL DoWindowMessage ( HWND, unsigned, WPARAM, LONG);
int PrintFunction (char*, char*);
void RedrawTerminal ( HDC );
void ClearDialogWnd ( void );
void GetUserCmd ( WORD, BOOL, int );
void CreateTerminal ( void );

