#include "setup.h"

void system ( char * );

#if IBM_TBC
#pragma argsused
#endif
void system ( char * CommandBuffer )
{
}
