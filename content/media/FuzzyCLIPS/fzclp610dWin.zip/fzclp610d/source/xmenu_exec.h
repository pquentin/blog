/*  $Header: /dist/CVS/fzclips/src/xmenu_exec.h,v 1.3 2001/08/11 21:08:35 dave Exp $  */

void ResetCallback(Widget,XtPointer,XtPointer);
void RunCallback(Widget,XtPointer,XtPointer);
void StepCallback(Widget,XtPointer,XtPointer);
void ClearCLIPSCallback(Widget,XtPointer,XtPointer);
void ClearScreenCallback(Widget,XtPointer,XtPointer);
